class RasulUlulAzmi{
    constructor(){
        this.nama = ""
        this.kelahiran = ""
        this.usia = ""
        this.daerah = ""
        this.keturunan = ""
        this.kaum = ""
        this.mukjizat = ""
        this.alquran = ""
    }

    dakwah(kaum){
        console.log("Berdakwah kepada" + kaum);
    }
}

Nuh = new RasulUlulAzmi()
let n = Nuh.nama = "Nuh as"
let nk = Nuh.kelahiran = "3993-3043 SM"
let nu = Nuh.usia = "950 tahun"
let nd = Nuh.daerah = " Irak Bagian Selatan"
let nkt = Nuh.keturunan = "Nabi Syits bin Adam"
let nkm = Nuh.kaum = "Nuh" 
let nm =  Nuh.mukjizat = "Mendatangkan Banjir yang Besar"
let na = Nuh.alquran = "43 kali disebut" 


Ibrahim = new RasulUlulAzmi()
let i = Ibrahim.nama = " Ibrahim as"
let ik = Ibrahim.kelahiran = "1997-1822 SM"
let iu = Ibrahim.usia = " 175 tahun"
let id = Ibrahim.daerah = "Ur, Babylon selatan (Sekarang Irak)"
let ikt = Ibrahim.keturunan = "Sam bin Nuh"
let ikm = Ibrahim.kaum = "Bangsa Kaldan"
let im = Ibrahim.mukjizat = "Mendatangkan Banjir yang Besar"
let ia = Ibrahim.alquran = " 69 kali namanya di sebut"


Musa = new RasulUlulAzmi()
let m = Musa.nama = " Musa as"
let mk = Musa.kelahiran = "1527 - 1408 SM"
let mu =  Musa.usia = "120 tahun"
let md =  Musa.daerah = "Mesir"
let mkt = Musa.keturunan = "Yaqub bin Ishak"
let mkm =  Musa.kaum = "Bani Israil"
let mm =  Musa.mukjizat = "Tongkat Nabi Musa as bisa berubah menjadi ular dan membelah lautan"
let ma =  Musa.alquran = " 136 kali namanya di sebut"


Isa = new RasulUlulAzmi()
let isa = Isa.nama = " Isa as"
let ikn = Isa.kelahiran = "1SM - 32M"
let iua = Isa.usia = "40 tahun selama di bumi"
let idh = Isa.daerah = "Palestina"
let iknn = Isa.keturunan = "Sulaiman bin Daud"
let ikum = Isa.kaum = "Bani Israil"
let imt = Isa.mukjizat = "Menghidupkan Orang yang Mati"
let ian = Isa.alquran = " 55 kali namanya di sebut"


MuhammadSaw = new RasulUlulAzmi()
let ms = MuhammadSaw.nama = " Muhammad Saw"
let msk = MuhammadSaw.kelahiran = "571M - 632M"
let msu = MuhammadSaw.usia = "63 tahun"
let msd = MuhammadSaw.daerah = "Mekkah dan Madinaha"
let mskn = MuhammadSaw.keturunan = "Ibrahim"
let mskm = MuhammadSaw.kaum = "Seluruh manusia dan alam semesta"
let mskt = MuhammadSaw.mukjizat = "Al-Quran, Membelah Bulan, Makanan yang Sedikit Cukup untuk Banyak Orang"
let msa = MuhammadSaw.alquran = " 4 kali namanya di sebut, Tetapi banyak juga kata-kata dalam Al-Qur'an yang merujuk kepada nama Nabi Muhammad, seperti Rasulullah, Nabi, dan lain-lain "

Nuh.dakwah(Nuh.kaum)
Ibrahim.dakwah(Ibrahim.kaum)
Musa.dakwah(Musa.kaum)
Isa.dakwah(Isa.kaum)
MuhammadSaw.dakwah(MuhammadSaw.kaum)

const rasulululazmi = [
    Nuh,
    Ibrahim,
    Musa,
    Isa,
    MuhammadSaw
]

for(rasul5 of  rasulululazmi){
    console.log(rasul5);
}